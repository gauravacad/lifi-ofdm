## Donation
If this project help you reduce time to develop, please make a small donation. I suggest **$5**, but you can choose the amount. We need your help to pay for web hosting, buy new components and equipment for new tutorials, and buy a cup of coffee :). Alternately, you can make a donation by sending me Bitcoin, at address **1JN3zEw8NqCr8bn4UQa3TfZXaz7UZnb5bH**

[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://paypal.me/erwin168?locale.x=en_US)
